# Upwork-additional-questions-and-answers-of-job-application
Additional Questions and Answers of Upwork Job Application

<b>1. What past project or job have you had that is most like this one and why?</b>
<p>Ans: According to your job requirements, I have done many projects like yours. For more details you can check my portfolio, profiles and employment history where you will find the similar projects like your desire one.</p>

<b>2. Do you have suggestions to make this project run successfully?</b>
<p>Ans: Sure I have suggestions for you in this project. According to my concept, the updated strategy and proper methods can make this project successful. And surely I will make this project successful.</p>

<b>3. Which part of this project do you think will take the most time?</b>
<p>Ans: According to your job details, I have years of experiences in both fields. And I always use the updated techniques and win the competition. I have a strong belief that I would be able to make this project successful within short time.</p>

<b>4. Have you taken any oDesk/Upwork tests and done well on them that you think are relevant to this job?</b>
<p>Ans: Yes I have taken oDesk/Upwork Skill Tests and I have done well. You can check my tests area. Default system of odesk/Upwork tests is a good method of justify oneself. And yes I appreciate it as well as I did well in here.</p>

<b>5. How much time do you think it will take to accomplish the task for google results ?</b>
<p>Ans: Competition is everywhere. Always want to be ranked in google. But failing in this competition is problematic. And I know this problem. The problem is the so called workers do not use the updated methods where I always hit the iron when it is hot. That’s why I can assure you that I will be able to do it in short times than the rest (2+ or 3+ months)</p>

<b>6. What part of this project most appeals to you?</b>
<p>Ans: Here the two parts of this project appeal me very much, one is that all the requirements are in favor of me and the second one is I like to do these kind of job. These kind of project and job give me mental satisfaction.</p>

<b>7. Why do you think you are a good fit for this particular project?</b>
<p>Ans: I think I am a good fit for this job because I have all the qualities that you are looking for. Experience is the golden factor in this project where you find in me at least 3+ years of working experiences over all the factors in your project.</p>

<b>8. Do you have any questions about the job description?</b>
<p>Ans: Your arrangement of the job description is fully understandable and I have understood it very well. Still I have no questions about your job description. If I need any information latter, I must convey you and discuss with you in a friendly circumstances.</p>

<b>9. Which of the required job skills do you feel you are strongest at?</b>
<p>Ans: I have carefully read your job description and I have more than 3 years of working experience in both of your required skills. And I am strongest at all of your required qualities. Hope I will be the perfect worker for you in this project.</p>

<b> 10. What SEO jobs have you done in the past?</b>
<p>Ans: I have successfully completed many seo projects before, you can see my employment history and portfolio projects. I hope I will also be successful in this project. You can undoubtedly hire me.</p>

<b>11. How much time will you need to work on this project to see results and how will you spend your time working on this project?</b>
<p>Ans: I have a strong belief that I would be able to make this project successful within short time. I will spend my time working on this project hourly with white hat updated method and make it successful.</p>

<b>12. Have you done high quality back-linking before? if so what sites do you use?</b>
<p>Ans: Sure I have done high PR back-inkling before and ranked many sites. You can check my employment history and portfolio. (You can also include some links here)</p>

<b>13. Why should i chose you over the other 100 that have applied for this Job?</b>
<p>Ans:  This is a good point you have asked. Here you will found many so called worker who do not know how to work. I am totally different from them. I have a long term plan to work in here, that’s why I am here with all qualities and experiences. I am here not to cheat you rather help you.</p>

<b>14. What challenging part of this job are you most experienced in?</b>
<p>Ans: Everything is now becoming challenging, If one has to win he or she should have the proper knowledge of the present situation. And I am most experienced in this factor. Hope I will make your project successful.</p>

<b>15. Who have you worked with that has yielded quick results. What was the cost to client to receive positive results?</b>
<p>Ans: I have successfully completed many projects. You can see my portfolio and employment history. And I took the relevant cost, I never ask for high price.</p>

<b>16. Tell me how you would go about increasing my rankings for my website?</b>
<p>Ans: Ranking a website on some certain keywords are now very difficult. But if one has relevant ideas and skills about the search engines’ logarithm, he/she must win this competition. According to that I will first make your site search engine friendly then I will make it popular to others and increase its rank.</p>

<b>17. Why did you apply to this particular job?</b>
<p>Ans: I have applied to this particular job because all the requirements of this project are in favor of me and I can 100% assure you that I must be successful in this project and satisfy you. I never apply to any job what doesn’t match my skills.</p>

<b>18. Have you read the job description fully and understand it and feel you are an ideal candidate for the job?</b>
<p>Ans: Great question. I never take any attempt without having the full knowledge of a matter. I have carefully read the job description and only then I decided to apply when I thought; I am the best one for this project. You can undoubtedly hire me.</p>

<b>19. What questions do you have about the project?</b>
<p>Ans: I have read the whole job description and it is really informative. I did not found anything that is irrelevant to me. I have understood every single part of the job description. Still I have not any question about the project. If I need any further help, I must ask you.</p>

<b>20. Do you have previous experience? If so, do you have some examples?</b>
<p>Ans: This is a good question, my dear client. And yes, I have a lot of previous experiences. For more on it please check my profile, work history and feedback. I have also added some portfolio that is more relevant to your question. Thanks a lot.</p>

<h2>Type 2</h2>

<b>Have you taken any oDesk tests and done well on them that you think are relevant to this job?</b>
<p>Yes.</p>

<b>Why did you apply to this particular job?</b>
<p>Because I can do it .</p>

<b>Which part of this project do you think will take the most time?</b>
<p>Thinking of creative concepts and ideas.</p>

<b>Do you have suggestions to make this project run successfully?</b>
<p>I think that good communication between employee and employer is most important. If communication is good, each project ends well.</p>

<b>Why do you think you are a good fit for this particular project?</b>
<p>Got the confidence that i would be able to deliver the result.</p>

<b>What challenging part of this job are you most experienced in?</b>
<p>I enjoy challenges. Every project is a new challenge but I believe in design that stand out from crowd & i work until client’s 100% sanctification. Challenges comes & challenges goes, I experienced & prepared myself for the next to keep lesson in my mind that it is only to make you more strong. Please check my artwork sample from the attachment so that you could understand my level of work & experience in graphic designing.</p>

<b>Which of the required job skills do you feel you are strongest at?</b>
<ol>
	<li>24/7 Availability & Quick Response</li>
	<li>Ready to Start Now & Quick Turn-Around-Time Guaranteed.</li>
	<li>100% Full-Time Freelance Graphics Designer</li>
	<li>Quality Industry Experience.</li>
	<li>Flexible & Unlimited changes. (Reasonable)</li>
	<li>Wide knowledge about designing (Print, Online, Web, Application)</li>
	<li>One and only designer who promised you utmost Quality</li>'
</ol>

<b>What past project or job have you had that is most like this one and why?</b>
<p>I have been designing Logos since 2008 and so far gained experience in almost all fields .This job will provide me one more opportunity to work.</p>

<b>What part of this project most appeals to you?</b>
<p>Whole job. And I’ll take whole job as a challenge.</p>

<b>What versions of HTML are you planning to use and why?</b>
<p>It will be decided after analyzing the concepts and ideas for the website properly.</p>

 
<b>What past project or job have you had that is most like this one and why?</b>

<p>For more details you can check my portfolio and employment history where you will find the similar projects like your desire one. This job will provide me one more opportunity to work.</p>

 

<b>What part of this project most appeals to you?</b>

<p>Whole job and I’ll take whole job as a challenge.</p>

 

<b>What challenging part of this job are you most experienced in?</b>

<p>If anyone has to perform excellent he/she should have the proper knowledge of the present situation. And I am well experienced in this factor. Hope I will make your project successful.

Photoshop, Designing, HTML5, CSS3, jQuery, Java Script, Bootstrap, PHP and WordPress</p>

 

<b>Which part of this project do you think will take the most time?</b>

<p>According to your job details, I have a strong belief that I would be able to complete this project successfully within short time.</p>

 

<b>Which of the required job skills do you feel you are strongest at?</b>

<p>I have carefully read your job description; I am having expertise at all of your required qualities. Hope I will be the perfect worker for you in this project.</p>

 

<b>Why should i choose you over the other 100 that have applied for this Job?</b>

<p>It is a good thing you have asked. Here you will found many so called workers who do not know how to work. I am totally different from them. I have a long term plan to work in here, that’s why I am here with all qualities and experiences. I am here not to cheat you.</p>

 

<b>Why do you think you are a good fit for this particular project?</b>

<p>I think I am a good fit for this job because I have all the qualities that you are looking for. Experience is the golden factor in this project where you find in me at least 4+ years of working experiences over all the factors in your project.</p>

 

<b>Do you have suggestions to make this project run successfully?</b>

<p>I think that good communication between employer and contractor is most important. If communication is good, each project ends well.</p>

 

<b>Do you have any questions about the job description?</b>

<p>Your job description is fully understandable, but I always prefer to have a conversation related to project requirements and other aspects, which helps in accomplishing the task as soon as possible.</p>

 

<b>Can you tell me, example landing pages are related to what?</b>

<p>A landing page is any page on a website where traffic is sent specifically to prompt a certain action or result.</p>
